from unicodedata import name
from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from .models import Customer, Product, Cart, OrderPlaced,Usersearch
from .forms import CustomerRegistrationForm, CustomerProfileForm
from django.views import View
from django.http import JsonResponse
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt





class ProductView(View):
	def get(self, request):
		totalitem = 0
		Thermocouple_Wire = Product.objects.filter(category='TC')
		Compensating_Pvc_Pvc_Cable = Product.objects.filter(category='CPPC')
		Fiberglass_Asbestos_Insulated_Thermocouple_Wire = Product.objects.filter(category='FAITW')
		Fiberglass_Insulated_Thermocouple_wire = Product.objects.filter(category='FITW')
		Fiber_Glass_Insulated_SS_Braided_Wire = Product.objects.filter(category='FGISBW')
		Ptfe_Teflon_Insulated_Wire = Product.objects.filter(category='PTIW')
		Compensating_J_Type_Cable = Product.objects.filter(category='CJTC')
		Asbestos_Braided_PVC_Wire = Product.objects.filter(category='ABPW')
		R_Type_Green_PT_RH_Rubber_Compensating_Cable= Product.objects.filter(category='RTGPRRCC')
		Thermocouple_Compensating_R_Type_Teflon_Wire = Product.objects.filter(category='P')
		Thermocouple_Extension_K_Type_Original_Teflon_Wire = Product.objects.filter(category='TEKTOTW')
		Thermocouple_S_Type_Teflon_Core = Product.objects.filter(category='TSTTC')
		Rtd_3_Core_SS_Braided_wire= Product.objects.filter(category='R3CSBW')
		Thermocouple_Compensating_Type_k_Teflon_Wire = Product.objects.filter(category='TCTKTW')
		Thermocouple_Connectors= Product.objects.filter(category='TCC')
		High_Temperature_Thermocouple_Cable = Product.objects.filter(category='HTTC')
		Pvc_Shielded_Cable= Product.objects.filter(category='PSC')
		Thermocouple_Compensating_R_Type_Teflon_Wiress = Product.objects.filter(category='TCRTTWW')


	
		if request.user.is_authenticated:
			totalitem = len(Cart.objects.filter(user=request.user))
		return render(request, 'app/home.html', {
			'tc':Thermocouple_Wire,
			'cppc':Compensating_Pvc_Pvc_Cable ,
			'faitw':Fiberglass_Asbestos_Insulated_Thermocouple_Wire, 
			'fitw':Fiberglass_Insulated_Thermocouple_wire,
			'fgisbw':Fiber_Glass_Insulated_SS_Braided_Wire,
			'ptiw':Ptfe_Teflon_Insulated_Wire ,
			'cjtc':Compensating_J_Type_Cable,
			'abpw':	Asbestos_Braided_PVC_Wire,
			'rtgprrcc':R_Type_Green_PT_RH_Rubber_Compensating_Cable,
			'p':Thermocouple_Compensating_R_Type_Teflon_Wire,
			'tektotw':Thermocouple_Extension_K_Type_Original_Teflon_Wire,
			'tsttc': Thermocouple_S_Type_Teflon_Core,
			'r3csbw':Rtd_3_Core_SS_Braided_wire,
			'tctktw':Thermocouple_Compensating_Type_k_Teflon_Wire ,
			'tcc':Thermocouple_Connectors,
			'httc':High_Temperature_Thermocouple_Cable,
			'psc':Pvc_Shielded_Cable,
			'tcrttww':Thermocouple_Compensating_R_Type_Teflon_Wiress,
			 'totalitem':totalitem
			

			
			   })

class ProductDetailView(View):
	def get(self, request, pk):
		totalitem = 0
		product = Product.objects.get(pk=pk)
		print(product.id)
		item_already_in_cart=False
		if request.user.is_authenticated:
			totalitem = len(Cart.objects.filter(user=request.user))
			item_already_in_cart = Cart.objects.filter(Q(product=product.id) & Q(user=request.user)).exists()
		return render(request, 'app/productdetail.html', {'product':product, 'item_already_in_cart':item_already_in_cart, 'totalitem':totalitem})

@login_required
def add_to_cart(request):
	user = request.user
	item_already_in_cart1 = False
	product = request.GET.get('prod_id')
	item_already_in_cart1 = Cart.objects.filter(Q(product=product) & Q(user=request.user)).exists()
	print(item_already_in_cart1)
	if item_already_in_cart1 == False:
		product_title = Product.objects.get(id=product)
		Cart(user=user, product=product_title).save()
		messages.success(request, 'Product Added to Cart Successfully !!' )
		return redirect('/cart')
	else:
		return redirect('/cart')
  # Below Code is used to return to same page
  # return redirect(request.META['HTTP_REFERER'])

@login_required
def show_cart(request):
	totalitem = 0
	if request.user.is_authenticated:
		totalitem = len(Cart.objects.filter(user=request.user))
		user = request.user
		cart = Cart.objects.filter(user=user)
		amount = 0.0
		shipping_amount = 70.0
		totalamount=0.0
		cart_product = [p for p in Cart.objects.all() if p.user == request.user]
		print(cart_product)
		if cart_product:
			for p in cart_product:
				tempamount = (p.quantity * p.product.discounted_price)
				amount += tempamount
			totalamount = amount+shipping_amount
			return render(request, 'app/addtocart.html', {'carts':cart, 'amount':amount, 'totalamount':totalamount, 'totalitem':totalitem})
		else:
			return render(request, 'app/emptycart.html', {'totalitem':totalitem})
	else:
		return render(request, 'app/emptycart.html', {'totalitem':totalitem})

def plus_cart(request):
	if request.method == 'GET':
		prod_id = request.GET['prod_id']
		c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
		c.quantity+=1
		c.save()
		amount = 0.0
		shipping_amount= 70.0
		cart_product = [p for p in Cart.objects.all() if p.user == request.user]
		for p in cart_product:
			tempamount = (p.quantity * p.product.discounted_price)
			print("Quantity", p.quantity)
			print("Selling Price", p.product.discounted_price)
			# print("Before", amount)
			amount += tempamount
			# print("After", amount)
		# print("Total", amount)
		data = {
			'quantity':c.quantity,
			'amount':amount,
			'totalamount':amount+shipping_amount
		}
		return JsonResponse(data)
	else:
		return HttpResponse("")

def minus_cart(request):
	if request.method == 'GET':
		prod_id = request.GET['prod_id']
		c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
		c.quantity-=1
		c.save()
		amount = 0.0
		shipping_amount= 70.0
		cart_product = [p for p in Cart.objects.all() if p.user == request.user]
		for p in cart_product:
			tempamount = (p.quantity * p.product.discounted_price)
			# print("Quantity", p.quantity)
			# print("Selling Price", p.product.discounted_price)
			# print("Before", amount)
			amount += tempamount
			# print("After", amount)
		# print("Total", amount)
		data = {
			'quantity':c.quantity,
			'amount':amount,
			'totalamount':amount+shipping_amount
		}
		return JsonResponse(data)
	else:
		return HttpResponse("")

@login_required
def checkout(request):
	user = request.user
	add = Customer.objects.filter(user=user)
	cart_items = Cart.objects.filter(user=request.user)
	amount = 0.0
	shipping_amount = 70.0
	totalamount=0.0
	cart_product = [p for p in Cart.objects.all() if p.user == request.user]
	if cart_product:
		for p in cart_product:
			tempamount = (p.quantity * p.product.discounted_price)
			amount += tempamount
		totalamount = amount+shipping_amount
	return render(request, 'app/checkout.html', {'add':add, 'cart_items':cart_items, 'totalcost':totalamount})

@login_required
def payment_done(request):
	custid = request.GET.get('custid')
	print("Customer ID", custid)
	user = request.user
	cartid = Cart.objects.filter(user = user)
	customer = Customer.objects.get(id=custid)
	print(customer)
	for cid in cartid:
		OrderPlaced(user=user, customer=customer, product=cid.product, quantity=cid.quantity).save()
		print("Order Saved")
		cid.delete()
		print("Cart Item Deleted")
	return redirect("orders")

def remove_cart(request):
	if request.method == 'GET':
		prod_id = request.GET['prod_id']
		c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
		c.delete()
		amount = 0.0
		shipping_amount= 70.0
		cart_product = [p for p in Cart.objects.all() if p.user == request.user]
		for p in cart_product:
			tempamount = (p.quantity * p.product.discounted_price)
			# print("Quantity", p.quantity)
			# print("Selling Price", p.product.discounted_price)
			# print("Before", amount)
			amount += tempamount
			# print("After", amount)
		# print("Total", amount)
		data = {
			'amount':amount,
			'totalamount':amount+shipping_amount
		}
		return JsonResponse(data)
	else:
		return HttpResponse("")

@login_required
def address(request):
	totalitem = 0
	if request.user.is_authenticated:
		totalitem = len(Cart.objects.filter(user=request.user))
	add = Customer.objects.filter(user=request.user)
	return render(request, 'app/address.html', {'add':add, 'active':'btn-primary', 'totalitem':totalitem})

@login_required
def orders(request):
	op = OrderPlaced.objects.filter(user=request.user)
	return render(request, 'app/orders.html', {'order_placed':op})

# def mobile(request, data=None):
# 	totalitem = 0
# 	if request.user.is_authenticated:
# 		totalitem = len(Cart.objects.filter(user=request.user))
# 	if data==None :
# 			mobiles = Product.objects.filter(category='M')
# 	elif data == 'Redmi' or data == 'Samsung':
# 			mobiles = Product.objects.filter(category='M').filter(brand=data)
# 	elif data == 'below':
# 			mobiles = Product.objects.filter(category='M').filter(discounted_price__lt=10000)
# 	elif data == 'above':
# 			mobiles = Product.objects.filter(category='M').filter(discounted_price__gt=10000)
# 	return render(request, 'app/mobile.html', {'mobiles':mobiles, 'totalitem':totalitem})


class CustomerRegistrationView(View):
 def get(self, request):
  form = CustomerRegistrationForm()
  return render(request, 'app/customerregistration.html', {'form':form})
  
 def post(self, request):
  form = CustomerRegistrationForm(request.POST)
  if form.is_valid():
   messages.success(request, 'Congratulations!! Registered Successfully.')
   form.save()
  return render(request, 'app/customerregistration.html', {'form':form})

@method_decorator(login_required, name='dispatch')
class ProfileView(View):
	def get(self, request):
		totalitem = 0
		if request.user.is_authenticated:
			totalitem = len(Cart.objects.filter(user=request.user))
		form = CustomerProfileForm()
		return render(request, 'app/profile.html', {'form':form, 'active':'btn-primary', 'totalitem':totalitem})
		
	def post(self, request):
		totalitem = 0


		
		if request.user.is_authenticated:
			totalitem = len(Cart.objects.filter(user=request.user))
		form = CustomerProfileForm(request.POST)
		if form.is_valid():
			
			usr = request.user
			name  = form.cleaned_data['name']
			locality = form.cleaned_data['locality']
			city = form.cleaned_data['city']
			state = form.cleaned_data['state']
			zipcode = form.cleaned_data['zipcode']

			reg = Customer(user=usr, name=name, locality=locality, city=city, state=state, zipcode=zipcode)
			reg.save()
			messages.success(request, 'Congratulations!! Profile Updated Successfully.')
		return render(request, 'app/profile.html', {'form':form, 'active':'btn-primary', 'totalitem':totalitem})

 

@csrf_exempt                
def search(request):
	if request.method == 'POST':
		if request.POST.get('search'):
		
			post=Usersearch()
			post.search=request.POST.get('search')
			post.save()
			return redirect('/')
	
	

def gate(request):
      return render(request,'gate.html')


def thermo(request):
      return render(request,'thermocouple/thermo.html')


def thermocable(request):
      return render(request,'thermocable2/home.html')


def fiberglass(request):
      return render(request,'fiberglass/home.html')


def fiberglass_insulated(request):
      return render(request,'fiber_insulated/home.html')





def team5(request):
      return render(request,'team5/home.html')



def team6(request):
      return render(request,'team6/home.html')


def team7(request):
      return render(request,'team7/home.html')


def team8(request):
      return render(request,'team8/home.html')


def team9(request):
      return render(request,'team9/home.html')


def team10(request):
      return render(request,'team10/home.html')


def team11(request):
      return render(request,'team11/home.html')


def team12(request):
      return render(request,'team12/home.html')


def team13(request):
      return render(request,'team13/home.html')


def team14(request):
      return render(request,'team14/home.html')


def team15(request):
      return render(request,'team15/home.html')


def team16(request):
      return render(request,'team16/home.html')


def team17(request):
      return render(request,'team17/home.html')


def team18(request):
      return render(request,'team18/home.html')


def team19(request):
      return render(request,'team19/home.html')


def team20(request):
      return render(request,'team20/home.html')


def team21(request):
      return render(request,'team21/home.html')


def team22(request):
      return render(request,'team22/home.html')


def team23(request):
      return render(request,'team23/home.html')

